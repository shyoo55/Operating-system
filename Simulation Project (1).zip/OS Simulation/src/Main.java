import java.io.FileWriter;
import java.util.Queue;

public class Main {
public static void main(String[] args) {
		
int numberOfJobs=10000000;
Queue<Job> newJobs = OperatingSystem.newJob(numberOfJobs);

//Queue<Job> jobs=OperatingSystem.readFile("Job.TXT");

Queue<Job> ssrJobs=OperatingSystem.ssrPolicy(newJobs); 

Hardware.hdJobs(ssrJobs);
		
//////////////////////////////////////////
	
if (!Hardware.HardDisk.isEmpty()) {	
Hardware.cPRam();
CPU.exProc(ssrJobs);}
		
//////////////////////////////////////////

OperatingSystem.wrFile(CPU.processedJobs);


		
if(Hardware.numP>0 ) {
System.out.println("\nResult :\n\nThe number of jobs processed : "+Hardware.numP + "\n"
+"The average program size of all jobs: " + Hardware.mSize / Hardware.numP +" KB\n"
+ "The min of job size: " + OperatingSystem.minValue +" KB\n"
+ "The max of job size: " + OperatingSystem.maxValue +" KB");
System.out.println("The number of jobs that have completed their execution normally:  " +  Job.normally );
System.out.println("The number of jobs that have completed their execution abnormally: " +Job.abnormally);  // /Hardware.NumOfProcess


System.out.println("\n\n\n*************** Terminating Processes Report ***************\n\n");
for (int i=0;i<CPU.processedJobs.size();i++)
{
	Job job=CPU.processedJobs.poll();
	System.out.println("\n\nProcess ID (PID) :"+job.getPcb().getID() );
	System.out.println("CPU usage term (CUT) :"+job.getPcb().getPCunt());
	System.out.println("Termination Status :"+job.getTerminationType()+"\n\n");	
}

}
else {
System.out.println("The number of jobs processed : 0" + "/n");}             
                
try {	
FileWriter writer1 = new FileWriter("/Users/HINDALQAHTANI/Desktop/C/Result.TXT");
if(Hardware.numP>0 ) {
writer1.write("\nResult :\n\nThe number of jobs processed: "+Hardware.numP + "/n"
+"The average program size of all jobs: " + Hardware.mSize / Hardware.numP +" KB"
+ "The min of job size: " + OperatingSystem.minValue +" KB " +
"The max of job size: " + OperatingSystem.maxValue +" KB "+
"The number of jobs that have completed their execution normally: " + Job.normally+ 
"The number of jobs that have completed their execution abnormally:" + Job.abnormally+
"\n\n");
writer1.write("\n\n*************** Terminating Processes Report ***************\n\n");
for (int i=0;i<CPU.processedJobs.size();i++)
{
	Job job=CPU.processedJobs.poll();
	writer1.write("\nProcess ID (PID) :"+job.getPcb().getID()+"\nCPU usage term (CUT) :"+job.getPcb().getPCunt()+"\n"
			+ "Termination Status :"+job.getTerminationType()+"\n");	
}

}//End if

else {
writer1.write("The number of jobs processed : 0"+"/n");}//End else
                    
writer1.close();}//End try
catch (Exception e) {
System.out.println(e.getMessage());}//End catch
}//end method
//////////////////////////////////////////
}