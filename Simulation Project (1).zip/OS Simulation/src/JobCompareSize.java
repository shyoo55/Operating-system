import java.util.Comparator;

public class JobCompareSize implements Comparator<Job>{ //
	
public int compare(Job j1, Job j2) {
   int sJob1=j1.getPcb().getJobSize(); //size job 1
   int sJob2=j1.getPcb().getJobSize(); //size job 2
   
   return sJob1-sJob2;}

//End class
}