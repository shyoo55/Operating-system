import java.util.UUID; //  immutable universally unique identifier (UUID). A UUID represents a 128-bit value.

public class PCB {

private String ID;
private int JobSize;
private int ExJobTime;//Execution JobExecution Time
private JobState State;
private int PCunt;//program counter

//////////////////////////////////////////
public PCB(int jobSize,int exJobTime,JobState State) {
   this.JobSize = jobSize;            
   this.ExJobTime = exJobTime;
   this.State = State;
   ID = UUID.randomUUID().toString(); }
//////////////////////////////////////////
//////////////////////////////////////////
public void incrementPCunt() {
if (ExJobTime >= PCunt) { // 1 UT = one instruction 
PCunt++;}}
//////////////////////////////////////////

public String getID() {
   return ID;}
//
public void setID(String iD) {
   ID = iD;}
//
public int getJobSize() {
   return JobSize;}
//
public void setJobSize(int jobSize) {
   JobSize = jobSize;}
//
public int getExJobTime() {
   return ExJobTime;}
//
public void setExJobTime(int exJobTime) {
   ExJobTime = exJobTime;}
//          
public JobState getState() {
   return State;}
//
public void setState(JobState state) {
   State = state;}
//
public int getPCunt() {
   return PCunt;}
//
public void setPCunt(int pCunt) {
PCunt = pCunt;}

//End class
}