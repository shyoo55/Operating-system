import java.util.LinkedList;
import java.util.Queue;

public class Job {

private PCB pcb;
private TerminationType tType;
public static int normally;
public static int abnormally;
public JobState jState;


/////////////////////////////////////////////////
public Job(int jobSize,int jobExecutionTime,JobState state) {
   this.jState=state;
   this.pcb = new PCB(jobSize,jobExecutionTime,jState);}

public void checkTerminate(int Tscoure) {
   if (Tscoure <= 10) {
   setTerminationType(TerminationType.Noramally);
   normally++;
   return;}

if (Tscoure <=15 ) {
   setTerminationType(TerminationType.Abnormally);
   abnormally++;
   return;}

else
   setTerminationType(TerminationType.Other);}
/////////////////////////////////////////////////
/////////////////////////////////////////////////
public TerminationType getTerminationType(){
   return tType;}
//
public void setTerminationType(TerminationType tType){

   this.tType = tType;}
//

public PCB getPcb() {
   return pcb;}
   
//End class
}