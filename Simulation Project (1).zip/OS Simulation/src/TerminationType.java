enum TerminationType {
Noramally, Abnormally, Other, NotDetirmined;
}