import java.util.LinkedList;
import java.util.Queue;

public class CPU {

	public static Queue<Job> processedJobs = new LinkedList<Job>();
	static Queue<Job> nJobs= new LinkedList<Job>(); 
	static Queue<Job> abJobs= new LinkedList<Job>(); 

public static void exProc(Queue<Job> jobs){ 
  
	while (!Hardware.Ram.isEmpty()) {
   Job job = Hardware.Ram.poll();
   // Updates process status //             
   while(job.getPcb().getState()!=JobState.TERMINATED) {
   job.getPcb().setState(JobState.READY);
   
   
   while (job.getPcb().getExJobTime() > job.getPcb().getPCunt()) {
   job.getPcb().setState(JobState.RUNNING);
   job.getPcb().incrementPCunt();
 }
   
   
   job.checkTerminate((int) (Math.random() * 100 + 1));	
   processedJobs.add(job);
   job.getPcb().setState(JobState.TERMINATED);}
   }
   if (Hardware.Ram.isEmpty()) {
   Hardware.Ram.add(Hardware.HardDisk.poll());}
}
//End class
}

