import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.PriorityQueue;
import java.io.File;
import java.io.FileWriter;
import java.util.Comparator;

public class OperatingSystem {
static int allExTime=0; //all execution time
static Queue<Job> jobs = new LinkedList<Job>();
static int maxValue=0; //to put limit on the min value
static int minValue=1000000; //to put limit on the max value

//////////////////////////////////////////
public static Queue<Job> newJob(int numOfJobs){ //create new job
if (numOfJobs > 0) {
// The numbers below are given in the project document
int maxSize = 256; // KB EMR between 16 KB and 256 KB
int minSize = 16; // KB
			
int maxTime = 512; // unit of time
int minTime = 16; // unit of time
int sizeRange = maxSize - minSize;
int timeRange = maxTime - minTime;

		
for (int i = 0; i < numOfJobs; i++) {
int JobSize = (int) (Math.random() * sizeRange) + minSize; //random size     
int JobExecutionTime = (int) (Math.random() * timeRange) + minTime; //random execution time

if (Hardware.isAccommodateJob(JobSize)){ //if there is space in the memory

Job job = new Job(JobSize,JobExecutionTime,JobState.NEW);
jobs.add(job);
allExTime=allExTime+job.getPcb().getExJobTime();// execution time for all processes             
if(job.getPcb().getJobSize() > maxValue){
maxValue = job.getPcb().getJobSize();}//end if
if(job.getPcb().getJobSize() < minValue){
minValue = job.getPcb().getJobSize();}//end if 
}//end big if

else 
break;}

return jobs;}
else {
System.out.println("No jobs is created. Since wrong number of processes!/nPlease Enter a valid number > 0");
return null;}}
//////////////////////////////////////////
//////////////////////////////////////////
public static void wrFile(Queue<Job> jobs){ // write to file 

try { 
FileWriter writer = new FileWriter("/Users/HINDALQAHTANI/Desktop/C/Job.TXT");

for (int i=0;i<jobs.size();i++) {
Job job=jobs.poll();


writer.write("\nJob ID : " + job.getPcb().getID() + 
		"\nJob State : " + job.getPcb().getState()+
		"\n+Expected memory requirement (EMR) : " + job.getPcb().getJobSize()+" KB" +
		"\n"+"Expected CPU usage (ECU) : " + job.getPcb().getExJobTime()+" TU" +
		"\n"+"CPU usage term (CUT) : "+job.getPcb().getPCunt()+
		"\nTermination Type : "+job.getTerminationType()+"\n\n\n");        
}//end for

writer.close();} 
catch (Exception e){
System.out.println(e.getMessage());}
}
//////////////////////////////////////////

//////////////////////////////////////////
public static Queue<Job> readFile(String fileName) {
	Queue<Job> queue=new LinkedList<Job>();

	try { 
	File myObj=new File("/Users/HINDALQAHTANI/Desktop/C/Job.TXT");
	Scanner myReader=new Scanner(myObj);
	while(myReader.hasNextLine()) {
		String data=myReader.nextLine();
		int jobId=Integer.parseInt(data.substring(9));
		
		data=myReader.nextLine();
		int emr=Integer.parseInt(data.substring(37));
		
		data=myReader.nextLine();
		int ecu=Integer.parseInt(data.substring(27));

		Job job = new Job(jobId,ecu,JobState.NEW);
			jobs.add(job);
	}
	}
catch(Exception c) {
	System.out.println(c.getMessage());
}
	
	return queue;
}
//////////////////////////////////////////
//////////////////////////////////////////
public static Queue<Job> ssrPolicy(Queue<Job> jobs) { 
																	
Comparator<Job> comparator = new JobCompareSize();
PriorityQueue<Job> priority = new PriorityQueue<Job>(jobs.size(), comparator);																		

for (Job job : jobs) {
	priority.add(job);
}
return priority;
}

//////////////////////////////////////////

// End class

}