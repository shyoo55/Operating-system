import java.util.LinkedList;
import java.util.Queue;

public class Hardware {

//A hard disk with 2 GB available for user programs (convert to kb because the output is required with kb)
final static int hdSize = 2 * 1024 * 1024; //hard disk size

//A RAM with 192 MB available for user programs (convert to kb because the output is required with kb)
final static int rSize = 192 * 1024; //ram size

//////////////////////////////////////////
final static int uSpace = hdSize; //user space
public static int mSize = 0; //size of memory
	
public static Queue<Job> Ram = new LinkedList<Job>(); 
public static Queue<Job> HardDisk = new LinkedList<Job>();
	
/*initially number of processes is zero because we will
initiate number of processes randomly and automatically*/
public static int numP = 0; //number of process	

//////////////////////////////////////////

//check is there space to accommodate job
public static boolean isAccommodateJob(int size) {
   if ((mSize + size) <= uSpace) {
   mSize += size;
   return true;} 
   else{
   return false;}
}//end method
        
//////////////////////////////////////////
 
public static void hdJobs(Queue<Job> jobs){ //hard Disk jobs
   int JobsSize = 0;
   while (!jobs.isEmpty()) {
   Job job = jobs.poll(); 
   JobsSize += job.getPcb().getJobSize();
   HardDisk.add(job);}
}
	
//////////////////////////////////////////

public static void cPRam(){ //carry process into ram  
   int JobsSize = 0;
   while (!HardDisk.isEmpty()) {
   numP++;

   if (JobsSize < rSize) {
   Job job = HardDisk.poll(); //returns and removes the element at the front the container
   JobsSize += job.getPcb().getJobSize();
   Ram.add(job);}//ens if
   else 
   break;}//end while
}//end method
	
//////////////////////////////////////////

//End class
}